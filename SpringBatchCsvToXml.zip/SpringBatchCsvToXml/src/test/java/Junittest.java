import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class Apptest implements ItemProcessor<ExamResult, ExamResult>{

	ExamResult examresult= new ExamResult();
	ExamResultItemProcessor examprocessor= new ExamResultItemProcessor();

    
    @Test
    public void testpercentage() {

      examresult.setPercentage("78");
		
      integer percentage = examprocessor.process(examresult);
      assertEquals(60, percentage, 0.0);
   }
}